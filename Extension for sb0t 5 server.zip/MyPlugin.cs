﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using iconnect;

namespace $safeprojectname$
{
    class MyPlugin : IExtension
    {
        /// <summary>Fires when the plugin has successfully loaded</summary>
        public void Load() { }

        /// <summary>Fires when the server has started</summary>
        public void ServerStarted() { }

        /// <summary>Fires each server thread cycle (approx 30ms)</summary>
        public void CycleTick() { }

        /// <summary>Fires when an unhandled packet is received</summary>
        public void UnhandledProtocol(IUser client, bool custom, byte msg, byte[] packet) { }

        /// <summary>Fires before a user is allowed to join</summary>
        public bool Joining(IUser client) { return true; }

        /// <summary>Fires after a user is allowed to join</summary>
        public void Joined(IUser client) { }

        /// <summary>Fires when a user was not allowed to join</summary>
        public void Rejected(IUser client, RejectedMsg msg) { }

        /// <summary>Fires before a user parts</summary>
        public void Parting(IUser client) { }

        /// <summary>Fires after a user parts</summary>
        public void Parted(IUser client) { }

        /// <summary>Fires when a user uploads a new avatar</summary>
        public bool AvatarReceived(IUser client) { return true; }

        /// <summary>Fires when a user uploads a new personal message</summary>
        public bool PersonalMessageReceived(IUser client, String text) { return true; }

        /// <summary>Fires when a message is received</summary>
        public void TextReceived(IUser client, String text) { }

        /// <summary>Fires before a message is broadcast</summary>
        public String TextSending(IUser client, String text) { return text; }

        /// <summary>Fires after a message is broadcast</summary>
        public void TextSent(IUser client, String text) { }

        /// <summary>Fires when a message is received</summary>
        public void EmoteReceived(IUser client, String text) { }

        /// <summary>Fires before a message is broadcast</summary>
        public String EmoteSending(IUser client, String text) { return text; }

        /// <summary>Fires after a message is broadcast</summary>
        public void EmoteSent(IUser client, String text) { }

        /// <summary>Fires before a private message is broadcast</summary>
        public void PrivateSending(IUser client, IUser target, IPrivateMsg msg) { }

        /// <summary>Fires after a private message is broadcast</summary>
        public void PrivateSent(IUser client, IUser target) { }

        /// <summary>Fires when the bot name receives a private message</summary>
        public void BotPrivateSent(IUser client, String text) { }

        /// <summary>Fires when the /nick command is used</summary>
        public bool Nick(IUser client, String name) { return true; }

        /// <summary>Fires when the /help command is used</summary>
        public void Help(IUser client) { }

        /// <summary>Fires when a browse item is received</summary>
        public void FileReceived(IUser client, String filename, String title, MimeType type) { }

        /// <summary>Fires before a user is ignored</summary>
        public bool Ignoring(IUser client, IUser target) { return true; }

        /// <summary>Fires after a user changes a target's ignore state</summary>
        public void IgnoredStateChanged(IUser client, IUser target, bool ignored) { }

        /// <summary>Fires when an invalid password is used</summary>
        public void InvalidLoginAttempt(IUser client) { }

        /// <summary>Fires when a user logs in</summary>
        public void LoginGranted(IUser client) { }

        /// <summary>Fires when a user's admin level changes</summary>
        public void AdminLevelChanged(IUser client) { }

        /// <summary>Fires before a user's registration is processed</summary>
        public bool Registering(IUser client) { return true; }

        /// <summary>Fires after a user's registration is processed</summary>
        public void Registered(IUser client) { }

        /// <summary>Fires after a user attempts to create an account using a bad password</summary>
        public void InvalidRegistration(IUser client) { }

        /// <summary>Fires after a user unregisters</summary>
        public void Unregistered(IUser client) { }

        /// <summary>Fires before the captcha is sent to a user</summary>
        public void CaptchaSending(IUser client) { }

        /// <summary>Fires after a user has replied to a captcha</summary>
        public void CaptchaReply(IUser client, String reply) { }

        /// <summary>Fires before a user changes vroom</summary>
        public bool VroomChanging(IUser client, ushort vroom) { return true; }

        /// <summary>Fires after a user changes vroom</summary>
        public void VroomChanged(IUser client) { }

        /// <summary>Fires before a user floods out</summary>
        public bool Flooding(IUser client, byte msg) { return true; }

        /// <summary>Fires after a user floods out</summary>
        public void Flooded(IUser client) { }

        /// <summary>Fires when a known proxy ip is detected</summary>
        public bool ProxyDetected(IUser client) { return true; }

        /// <summary>Fires when the /logout command is used</summary>
        public void Logout(IUser client) { }
        
        /// <summary>Fires when a user has idled</summary>
        public void Idled(IUser client) { }

        /// <summary>Fires when a user has unidled</summary>
        public void Unidled(IUser client, uint seconds_away) { }

        /// <summary>Fires when the ban lists are automatically cleared</summary>
        public void BansAutoCleared() { }

        /// <summary>Fires when a user sends an admin command</summary>
        public void Command(IUser client, String cmd, IUser target, String args) { }

        /// <summary>Fires when a link error occurs</summary>
        public void LinkError(ILinkError error) { }

        /// <summary>Fires when the chatroom connects to a Link Hub</summary>
        public void Linked() { }

        /// <summary>Fires when the chatroom disconnects from a Link Hub</summary>
        public void Unlinked() { }

        /// <summary>Fires when another leaf has connected to the Link Hub</summary>
        public void LeafJoined(ILeaf leaf) { }

        /// <summary>Fires when another leaf has disconnected from the Link Hub</summary>
        public void LeafParted(ILeaf leaf) { }

        /// <summary>Fires when a user has attempted to use an admin command in a room where it is unauthorised</summary>
        public void LinkedAdminDisabled(ILeaf leaf, IUser client) { }



        #region SERVER_INTERCONNECT

        public BitmapSource Icon { get; private set; }

        public UserControl GUI { get; private set; }

        public MyPlugin(IHostApp cb)
        {
            Server.SetCallback(cb);

            // set the GUI and icon for sb0t
            this.GUI = new MyGUI();
            this.Icon = null; // default icon
        }

        public void Dispose()
        {
            this.GUI = null;
            this.Icon = null;
        }

        #endregion
    }
}
